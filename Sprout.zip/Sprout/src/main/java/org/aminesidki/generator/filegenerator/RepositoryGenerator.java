package org.aminesidki.generator.filegenerator;

import com.github.mustachejava.Mustache;
import lombok.RequiredArgsConstructor;
import org.aminesidki.exception.FileSystemException;
import org.aminesidki.generator.importsgenerator.GenericImportsGenerator;
import org.aminesidki.generator.SproutFileGenerator;
import org.aminesidki.model.EntityMetadata;
import org.aminesidki.model.HelperMetadata;
import org.aminesidki.util.FileCreator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Specific implementation for repository classes generation of the <code>SproutFileGenerator</code>
 */
@RequiredArgsConstructor
public class RepositoryGenerator implements SproutFileGenerator {
    private final GenericImportsGenerator genericImportsGenerator;
    private final Map<String , EntityMetadata> em;
    private final Map<String , HelperMetadata> hm;

    @Override
    public void generate(EntityMetadata entityMetadata, Mustache mustache , String defDir, FileCreator fileCreator) throws IOException , FileSystemException{
        File repoFile = fileCreator.createFile(entityMetadata.className(), "Repository", defDir);

        try(BufferedWriter writer = new BufferedWriter(new FileWriter(repoFile))) {
            HashMap<String, Object> repoContext = new HashMap<>();

            repoContext.put("Imports", genericImportsGenerator.generate(entityMetadata, em, hm));
            repoContext.put("PackageName", entityMetadata.packageName());
            repoContext.put("ClassName", entityMetadata.className());
            repoContext.put("IdType", entityMetadata.id().type().regularName());

            mustache.execute(writer, repoContext);
        }
    }
}
